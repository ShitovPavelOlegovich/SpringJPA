package org.example.servises;


import org.example.model.Book;
import org.example.model.Person;
import org.example.repositories.BooksRepository;
import org.example.repositories.PeopleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional(readOnly = true)
public class PeopleService {

    private final PeopleRepository peopleRepository;

    private final BooksRepository booksRepository;

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public PeopleService(PeopleRepository peopleRepository, BooksRepository booksRepository, JdbcTemplate jdbcTemplate) {
        this.peopleRepository = peopleRepository;
        this.booksRepository = booksRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Person> findAll() {
        return peopleRepository.findAll();
    }

    public Person findOne(int id) {
        Optional<Person> person = peopleRepository.findById(id);
        return person.orElse(null);
    }

    @Transactional
    public void save(Person person) {
        peopleRepository.save(person);
    }

    @Transactional
    public void update(int id, Person updatePerson) {
        updatePerson.setId(id);
        peopleRepository.save(updatePerson);
    }

    @Transactional
    public void delete(int id) {
        peopleRepository.deleteById(id);
    }

    public List<Book> getBookByPerson(int id) {
        Optional<Person> person = peopleRepository.findById(id);
        if (person.isPresent()) {
            Person person1 = person.get();
            return booksRepository.findByOwner(person1);
        }
        return null;
    }

}
